Tinicum case study — Anthony Le
Beacon Fasteners purchasing copilot

This package contains:
- code/     runnable Python CLI
- outputs/  generated workbooks and audit files from the cached OpenAI run

Main business deliverables (open these first):
- outputs/lisa_reconciliation.xlsx          ACTION_QUEUE for Lisa
- outputs/vendor_performance.xlsx           plant-manager vendor discussion
- outputs/demo_notes.md                     30-minute presentation / live walkthrough script
- outputs/run_summary.md                    counts and assumptions for this run

How to run
1. Unzip this folder.
2. cd Anthony_Le_Tinicum_Case_Study/code
3. python -m venv .venv && source .venv/bin/activate
4. pip install -r requirements.txt
5. Copy .env.example to .env and set OPENAI_API_KEY (do not commit .env).
6. Place the supplied Beacon source data in ./data if it is not already present
   (open_pos.csv, vendor_master.csv, beacon_erp.db, and confirmation PDFs).
7. python main.py --data-dir ./data --output ../outputs
8. pytest

If no API key is set, the tool falls back to the local text/OCR parser.
Cached OpenAI extractions still count as OpenAI-backed; a rerun without
--refresh-cache does not mean AI was unused.
AI extracts document facts. Python computes quantity, price, date, matching, and OTD.
