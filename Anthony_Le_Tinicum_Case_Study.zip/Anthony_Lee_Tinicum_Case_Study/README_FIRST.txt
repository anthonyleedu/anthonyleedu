Tinicum case study — Anthony Lee
Beacon Fasteners purchasing copilot

This package contains:
- presentation/  10-minute walkthrough (PDF and PPTX)
- code/          runnable Python CLI
- outputs/       generated workbooks and audit files from the API-enabled run

Main business deliverables (open these first):
- outputs/lisa_reconciliation.xlsx          ACTION_QUEUE for Lisa
- outputs/vendor_performance.xlsx           plant-manager vendor discussion

How to run
1. Unzip this folder.
2. cd Anthony_Lee_Tinicum_Case_Study/code
3. python -m venv .venv && source .venv/bin/activate
4. pip install -r requirements.txt
5. Copy .env.example to .env and set OPENAI_API_KEY (do not commit .env).
6. Place the supplied Beacon source data in ./data if it is not already present
   (open_pos.csv, vendor_master.csv, beacon_erp.db, and confirmation PDFs).
7. python main.py --data-dir ./data --output ../outputs
8. pytest

If no API key is set, the tool falls back to the local text/OCR parser.
AI extracts document facts. Python computes quantity, price, date, matching, and OTD.
